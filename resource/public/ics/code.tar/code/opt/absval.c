/* $begin absval */
int absval(int val)
{
    return (val<0) ? -val : val;
}
/* $end absval */

