#!/usr/bin/perl
#!/usr/local/bin/perl 
use Getopt::Std;
use lib ".";
use config;

########################################################################
# readspool.pl - Scans the email spool file once, reading entries for the 
#     Data Lab "Beat the Prof" contest, and generates an html page.
#
# Copyright (c) 2003, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
########################################################################

##################################################################
# Instructors: change the following variables for your environment
##################################################################

$| = 1; # autoflush output on every print statement

# Any files created by this script are readable only by the user
umask(0077); 

#
# usage - print help message and terminate
#
sub usage {
    printf STDERR "$_[0]\n";
    printf STDERR "Usage: $0 [-h]\n";
    printf STDERR "Options:\n";
    printf STDERR "  -h   Print this message.\n";
    die "\n";
}

##############
# Main routine
##############

# 
# Parse the command line arguments
#
getopts('h');
if ($opt_h) {
    usage();
}

open(SPOOL, $SPOOL_FILE) 
    or die "$0: ERROR: could not open spool file ($SPOOL_FILE) for reading\n";

# Get ready to read
%RESULTS = ();         # Initialize the results hash
$BIGNUM = 9999999999;  # Impossibly large number of operations
$THRESHOLD = -1000;     # Highly improbable number of correct operations
$maxpuzzlenum = 0;     # Largest puzzle id number
@puzzlename = ();      # Array of puzzle names

# Read each line in the spool file
while ($line = <SPOOL>) {
    chomp($line);

    # Only consider text lines from this instance of the datalab
    if ($line =~ /$CONTEST_KEY:$LABID/) {

	# Note that spitting this way allows the teamname to have colons
	$line =~ /$CONTEST_KEY:$LABID:(\d+):(.+):(\w+):(\d+):(\d+)$/;
	$puzzlenum = $1;
	$teamname = $2;
	$puzzle = $3;
	$errors = $4;
	$ops = $5;

	$puzzlename[$puzzlenum] = $puzzle;

	# As we scan the file, determine the number of puzzles 
	if ($puzzlenum > $maxpuzzlenum) {
	    $maxpuzzlenum = $puzzlenum;
	}

	# If we haven't encountered this team and puzzle before, then init ops
	if (!$RESULTS{$teamname}[$puzzlenum]) {
	    $RESULTS{$teamname}[$puzzlenum] = $BIGNUM;
	}

	# We're only going to consider this entry if it is correct (errors == 0)
	# and it was solved in fewer ops than previous submission from this team
	if ($errors == 0 and $ops < $RESULTS{$teamname}[$puzzlenum]) {
	    $RESULTS{$teamname}[$puzzlenum] = $ops;
	}
    }
}
close(SPOOL);

# 
# Abort if the instructor hasn't submitted an entry to the contest yet
# 
$RESULTS{$BASE_TEAMNAME} 
    or die "$0: ERROR: Instructor needs to submit before contest \"$LABID\" can begin\n";

# 
# Determine the baseline operation counts for each puzzle
#
$puzzlecnt = $maxpuzzlenum +1;
for ($i = 0; $i < $puzzlecnt; $i++) {
    $baseops[$i] = $RESULTS{$BASE_TEAMNAME}[$i];
}

#
# Build a hash of the total score for each team
#
%SCORE = ();
foreach $teamname (sort {$a <=> $b} keys %RESULTS) {
    $score = 0;
    for ($i = 0; $i < $puzzlecnt; $i++) {
	$score += ($baseops[$i] - $RESULTS{$teamname}[$i]);
    }
    $SCORE{$teamname} = $score;
}


# 
# Emit Web page sorted with highest scores first
#
open(WWW, ">$WEB_PAGE") 
    or die "$0: ERROR: Couldn't open $WEB_PAGE\n";

print WWW <<"EOF";
<html>
<head>
<title>CS:APP Data Lab Contest Results</title>
</head>
<body bgcolor=white>

<h2>$LAB_TITLE</h2>
This page shows the operator counts for the students who
have submitted entries to the Data Lab "Beat the Prof" contest. 
<ul> 
<li> To enter the contest, copy the <kbd>submit.pl</kbd>
script to your <kbd>datalab-handout</kbd> directory, and then run 
<kbd>submit.pl</kbd>. 
<li> Enter as often as you like. The page will show only your best entries.
<li> Your instructor's puzzle entries are blue.
Green entries match the instructor. Red entries beat the instructor.
Incorrect entries are denoted by "-".
<li> Entries are sorted by score, defined as 
(total instructor operations - total student operations). 
<li> If all of your puzzle entries are correct and they match or beat 
the instructor, then you're a winner!

</ul>
EOF

print WWW "<p>Last updated: ", scalar localtime, "\n";

$cols = $puzzlecnt+3;

print WWW "<table border=0 cellspacing=1 cellpadding=1 cols=$cols>\n<p>\n";
print WWW "<tr align=\"center\">\n";

for ($i = 0; $i < $puzzlecnt; $i++) {
    print WWW "<td bgcolor=#aaaaaa width=20>$puzzlename[$i]</td>"
}
print WWW "<td bgcolor=#aaaaaa>Winner?</td>";
print WWW "<td bgcolor=#aaaaaa>Score</td>";
print WWW "<td bgcolor=#aaaaaa width=150>Team</td>";
print WWW "</tr>\n";

#
# print each student's entries in order by total score
#
foreach $teamname (reverse sort {$SCORE{$a} <=> $SCORE{$b}} keys %SCORE) {
    $winners = 0;
    print WWW "<tr align = \"center\">\n";
    for ($i = 0; $i < $puzzlecnt; $i++) {
	$ops = $RESULTS{$teamname}[$i];

	# The instructor's score is a special case
	if ($teamname eq $BASE_TEAMNAME) {
	    print WWW "<td bgcolor=#eeeeee><font color=blue><b>$ops</b></font></td>";
	}
	# Handle the student's submissions
	else {
	    # This is an entry that meets or beats the instructor
	    if ($ops <= $baseops[$i]) {
		$winners++;
		$color = "lime";
		if ($ops < $baseops[$i]) { 
		    $color = "red";
		}
		print WWW "<td bgcolor=#eeeeee><font color=$color><b>$ops</b></font></td>";
	    }

	    # This is an entry that didn't beat the instructor
	    else {
		if ($ops == $BIGNUM) { # btest found an error
		    print WWW "<td bgcolor=#eeeeee>-</td>";
		}
		else {  # OK, but too many ops
		    print WWW "<td bgcolor=#eeeeee>$ops</td>";
		}
	    }
	}
    }

    # This team wins if all puzzles meet or beat the instructor's
    $iswinner = ($winners == $puzzlecnt and $teamname ne $BASE_TEAMNAME);
    $entry = "";
    if ($iswinner) {
	$entry = "Winner!";
    }
    print WWW "<td bgcolor=#eeeeee>$entry</td>";
    
    # Print the total score and teamname
    if ($SCORE{$teamname} > $THRESHOLD) {
	print WWW "<td bgcolor=#eeeeee>$SCORE{$teamname}</td>";
    } else {
	print WWW "<td bgcolor=#eeeeee>-</td>";
    }
    
    if ($teamname eq $BASE_TEAMNAME) {
	print WWW "<td bgcolor=#eeeeee><font color=blue><b>$teamname</b></font></td>";
    }
    else {
	print WWW "<td bgcolor=#eeeeee>$teamname</td>";
    }
    print WWW "</tr>\n";
}

print WWW <<"EOF";
</table>
<hr>
<a href="$HOME_PAGE">Back to Course Home Page</a>
</body>
</html>
EOF

exit;



