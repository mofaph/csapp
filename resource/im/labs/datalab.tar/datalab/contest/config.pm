# Configuration information for datalab contest autograders.  

#########################################
# These are either site- or term-specific
#########################################

# What is the name of this instance of the contest?
# You'll need to change this each time you offer the lab.
$LABID = "fall02";

# What email spool file should programs look in to find contest entries?
# You'll only need to change this once.
$SPOOL_FILE = "/var/spool/mail/bomb";

# What team name (usually the instructor's team) should be used
# to determine the baseline operations counts?
$BASE_TEAMNAME = "The Prof";

# What heading do you want on the Web page?
# This is another one you'll need to change each time time you offer the lab.
$LAB_TITLE = '15-213 Fall, 2002 Data Lab "Beat the Prof" Contest';

# What is the URL for the class home page?
# You might need to change this each time you offer the lab.
$HOME_PAGE = "http://www.cs.cmu.edu/afs/cs/academic/class/15213-f02/www";

# Where should submit.pl send its email messages?
# They will be sent to $MAIL_USER@$MAIL_HOST. 
$MAIL_USER = "bomb";                    
$MAIL_HOST = "bluegill.cmcl.cs.cmu.edu";

# How should submit.pl invoke the mail delivery program?
# The script will deliver mail by running "$SENDMAIL_BIN $SENDMAIL_ARGS".
# What we've shown here is the default for Linux systems.
$SENDMAIL_BIN = "/usr/sbin/sendmail";   
$SENDMAIL_ARGS = "-bm";                 

# Where is the Web status page?
$WEB_PAGE = "/afs/cs/academic/class/15213-f02/www/daemons/dlcontest.html";

################################################
# You probably won't need to modify any of these
################################################

# What keyword is used to indicate a buffer bomb submission in the mail file?
$CONTEST_KEY = "datalab entry";

# How often should we try to update the Web status page? (seconds)
$SLEEP_TIME = 5;


