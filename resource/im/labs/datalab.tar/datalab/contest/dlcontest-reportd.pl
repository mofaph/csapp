#!/usr/bin/perl 
#!/usr/local/bin/perl
use lib ".";
use config;

#######################################################################
# dlcontest-reportd.pl - CS:APP data lab contest reporting daemon
#
# Copyright (c) 2003, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
#######################################################################

$0 =~ s#.*/##s;                  # this prog's basename (for error msgs)

# Repeated scan the spool file and regenerate the Web page
while (1) {
    # Scan spool file once and rebuild Web page
    system("./readspool.pl") == 0
	or die "$0: ERROR running spool scanner\n";

    # Wait for a bit, and then do it all over again
    sleep($SLEEP_TIME);
}

