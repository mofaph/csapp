#ifdef PROTOTYPE
int abs(int);
int test_abs(int);
#endif
#ifdef DECL
 {"abs", (funct_t) abs, (funct_t) test_abs, 1, "! ~ & ^ | + << >>", 10, 4,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
#endif
#ifdef CODE
/* 
 * abs - absolute value of x (except returns TMin for TMin)
 *   Example: abs(-1) = 1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 10
 *   Rating: 4
 */
int abs(int x) {
#ifdef FIX
  int mask = x>>31;
  return (x ^ mask) + ~mask + 1L;
#else
  return 2;
#endif
}
#endif
#ifdef TEST
int test_abs(int x) {
  return (x < 0) ? -x : x; 
}
#endif
