#ifdef PROTOTYPE
int sum3(int, int, int);
int test_sum3(int, int, int);
#endif
#ifdef DECL
 {"sum3", (funct_t) sum3, (funct_t) test_sum3, 3, "! ~ & ^ | << >>", 16, 3,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
#endif
#ifdef CODE
/* 
 * sum3 - x+y+z using only a single '+'
 *   Example: sum3(3, 4, 5) = 12
 *   Legal ops: ! ~ & ^ | << >>
 *   Max ops: 16
 *   Rating: 3
 */
/* A helper routine to perform the addition.  Don't change this code */
static int sum(int x, int y) {
  return x+y;
}

int sum3(int x, int y, int z) {
#ifdef FIX
  long int word1 = x^y^z;
  long int word2 = ((x&y)|(x&z)|(y&z)) << 1;
  return sum(word1,word2);
#else
  int word1 = 0;
  int word2 = 0;
  /**************************************************************
     Fill in code below that computes values for word1 and word2
     without using any '+' operations 
  ***************************************************************/

  /**************************************************************
     Don't change anything below here
  ***************************************************************/
  return sum(word1,word2);
#endif
}
#endif
#ifdef TEST
int test_sum3(int x, int y, int z)
{
  return x+y+z;
}
#endif
