#ifdef PROTOTYPE
int multFiveEights(int);
int test_multFiveEights(int);
#endif
#ifdef DECL
 {"multFiveEights", (funct_t) multFiveEights, (funct_t) test_multFiveEights, 1,
    "~ & ^ | + << >>", 12, 3,
  {{-(1<<29)-1, (1<<29)-1},{TMin,TMax},{TMin,TMax}}},
#endif
#ifdef CODE
/*
 * multFiveEights - multiplies by 5/8 rounding toward 0.
 *   Examples: multFiveEights(77) = 48
 *             multFiveEights(-22) = -13
 *   You can assume |x| < (1 << 29)
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 3
 */
int multFiveEights(int x) {
#ifdef FIX
  int fivex = ((x << 2) + x);
  int bias = (fivex >> 31) & 7;
  return (fivex + bias) >> 3;
#else
  return 2;
#endif
}
#endif
#ifdef TEST
int test_multFiveEights(int x)
{
  return (x*5)/8;
}
#endif

