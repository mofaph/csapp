#ifdef PROTOTYPE
int reverseBytes(int);
int test_reverseBytes(int);
#endif
#ifdef DECL
 {"reverseBytes", (funct_t) reverseBytes, (funct_t) test_reverseBytes, 1,
    "! ~ & ^ | + << >>", 25, 3,
  {{TMin, TMax},{TMin,TMax},{TMin,TMax}}},
#endif
#ifdef CODE
/* 
 * reverseBytes - reverse the bytes of x
 *   Example: reverseBytes(0x01020304) = 0x04030201
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 25
 *   Rating: 3
 */
int reverseBytes(int x) {
#ifdef FIX
  int result = (x & 0xff) << 24;
  result |= ((x >> 8) & 0xff) << 16;
  result |= ((x >> 16) & 0xff) << 8;
  result |= ((x >> 24) & 0xff);
  return result;
#else
  return 2;
#endif
}
#endif
#ifdef TEST
int test_reverseBytes(int x)
{
  union U {
    int result;
    char byte[4];
  };
  union U u;
  int temp;
  u.result = x;
  temp = u.byte[0];
  u.byte[0] = u.byte[3];
  u.byte[3] = temp;
  temp = u.byte[1];
  u.byte[1] = u.byte[2];
  u.byte[2] = temp;
  return u.result;
}
#endif
