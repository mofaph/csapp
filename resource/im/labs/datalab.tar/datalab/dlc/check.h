/* various constants */
#define MAXFUNCS 256
#define MAXOPS 128
#define MAXSTR 128

/* holds the list of legal functions and operators (defined in legallist.c) */
struct legallist {
    char name[MAXSTR]; /* legal function name */
    int callsok;       /* are function calls allowed in this function? */
    int maxops;        /* max operators for this function */
    int ops[MAXOPS];   /* null-terminated list of legal operators for this function */
};
