#!/usr/bin/perl 
#!/usr/local/bin/perl 
use Getopt::Std;
use lib ".";
use config;

#########################################################################
# grade-datalab.pl - Data Lab autograder
#
# Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
# This program automatically grades a Data Lab handin bits.c file and 
# prints a report on stdout that can be handed back to the students. 
#
# Example usage:
#     unix> ./grade-datalab.pl -f adamc-1-bits.c
# 
# Grading policy:
# Solutions that violate the coding rules get zero points. Solutions with 
# zero errors gets full points (given by the rating of the problem).
# Solutions with one error half credit. Solutions with more than one
# error get zero points.
#
#########################################################################

$| = 1; # autoflush output on every print statement

# Any files created by this script are readable only by the user
umask(0077); 

#
# usage - print help message and terminate
#
sub usage {
    printf STDERR "$_[0]\n";
    printf STDERR "Usage: $0 [-he] -f <filename> [-s <srcdir>]\n";
    printf STDERR "Options:\n";
    printf STDERR "  -h           Print this message.\n";
    printf STDERR "  -f <file>    C file to be graded.\n";
    printf STDERR "  -s <srcdir>  Location of directory with support code\n";
    printf STDERR "  -e           Don't include the original handin file on the grade sheet\n";
    die "\n";
}

##############
# Main routine
##############

# 
# Parse the command line arguments
#
getopts('hef:s:');
if ($opt_h) {
    usage();
}
if ((!$opt_f)) {
    usage("Missing required argument (-f)");
}

# 
# These optional flags override defaults in config.pm
#
if ($opt_s) {         # driver src directory
    $SRCDIR = $opt_s;
}

# 
# Initialize some file and path names
#
$infile = $opt_f;                         # input C file
($infile_basename = $infile) =~ s#.*/##s; # basename of input file

# absolute pathname of src directory
$srcdir_abs = `cd $SRCDIR; pwd`; 
chomp($srcdir_abs);

$dlc_dir = "$srcdir_abs/dlc";                 # dlc directory
$handout_dir = "$srcdir_abs/datalab-handout"; # handout directory
$btest_dir = "$srcdir_abs/btest";             # btest directory
$tmpdir = "/tmp/$infile_basename.$$";         # scratch directory
$0 =~ s#.*/##s;                               # this prog's basename

# 
# This is a message we use in several places when the program dies
#
$diemsg = "The files are in $tmpdir.";

# 
# Make sure the dlc and handout directories exist
#
(-d $dlc_dir and -e $dlc_dir)
    or  die "$0: ERROR: Directory $dlc_dir does not exist.\n";
(-d $handout_dir and -e $handout_dir) 
    or die "$0: ERROR: Directory $handout_dir does not exist.\n";

# 
# Make sure the input file exists and is readable
#
open(INFILE, $infile) 
    or die "$0: ERROR: could not open file $infile\n";
close(INFILE);

# 
# Set up the contents of the scratch directory
#
system("mkdir $tmpdir");
system("cp $infile $tmpdir/bits.c");

system("cp $btest_dir/btest.c $tmpdir");
system("cp $btest_dir/decl.c $tmpdir");
system("cp $btest_dir/tests.c $tmpdir");
system("cp $btest_dir/btest.h $tmpdir");
system("cp $btest_dir/bits.h $tmpdir");

system("cp $handout_dir/Makefile $tmpdir");

# Print header
print "\nCS:APP Data Lab: Grading Sheet for $infile_basename\n\n";

#
# Use dlc to zap any functions that violate the coding rules
#
print "Part 0: Compilation Results for Correctness Score\n\n";
print("Results of running 'dlc -z bits.c':\n");
system("(cd $tmpdir; cp bits.c save-bits.c)") == 0
    or die "$0: ERROR: Could not create backup copy of bits.c. $diemsg\n";
system("(cd $tmpdir; $dlc_dir/dlc -z -o zap.c bits.c)") == 0 
    or die "$0: ERROR: $infile_basename did not compile (dlc). $diemsg\n";

#
# Compile the zapped handin file into btest
#
print("Results of compiling btest:\n");
system("cp $tmpdir/zap.c $tmpdir/bits.c");
system("(cd $tmpdir; make clean > /dev/null 2>&1)");
system("(cd $tmpdir; make)") == 0
    or die "$0: ERROR: $infile_basename did not compile (c). $diemsg\n";

#
# Generate correctness score
#
print "\f\nPart 1: Correctness Tests (functions with invalid operations are disabled)\n\n";
print("Results of running 'btest -g':\n");
system("$tmpdir/btest -g") == 0
    or die "$0: ERROR: btest failed. $diemsg\n";

#
# Compile for performance test
#
print "\fPart 2: Compilation Results for Performance Score\n\n";
print("Results of running 'dlc -Z bits.c':\n");
system("(cd $tmpdir; $dlc_dir/dlc -Z -o zap.c save-bits.c)") == 0 
    or die "$0: ERROR: $infile_basename did not compile (dlc). $diemsg\n";

#
# Compile the zapped handin file into btest
#
print("Results of compiling btest:\n");
system("cp $tmpdir/zap.c $tmpdir/bits.c");
system("(cd $tmpdir; make clean > /dev/null 2>&1)");
system("(cd $tmpdir; make)") == 0
    or die "$0: ERROR: $infile_basename did not compile (c). $diemsg\n";

#
# Generate performance score
#
print "\f\nPart 3: Performance Tests (functions with invalid operations are disabled)\n\n";
print("\nResults of running 'btest -g -r 2':\n");
system("$tmpdir/btest -g -r 2") == 0
    or die "$0: ERROR: btest failed. $diemsg\n";

#
# Print the grade summary template that the instructor fills in
#
print "\f\nPart 4: Grade\n\n";
print "Correctness: \t\t     / $MAXCORR\n\n";
print "Performance: \t\t     / $MAXPERF\n\n";
print "Coding Style:\t\t     / $MAXSTYLE\n\n";
print "             \t\t__________\n\n";
print "Total:       \t\t     / ", $MAXCORR+$MAXPERF+$MAXSTYLE, "\n";   

# 
# Optionally print the original handin file 
#
if (!$opt_e) {
  print "\f\nPart 5: Original $infile file\n\n";
  system("cat $infile");
}

#
# Everything went OK, so remove the scratch directory
#
system("rm -fr $tmpdir");
exit;


