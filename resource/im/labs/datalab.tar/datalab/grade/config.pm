######################################################################
# Configuration file for the Data Lab autograders
#
# Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
######################################################################

#What is the name of this Lab?
$LABNAME = "datalab";

# How are the points distributed?
$MAXCORR = 40;     # Maximum correctness points
$MAXPERF = 30;     # Maximum performance points
$MAXSTYLE = 5;     # Maximum style points

# Where are the btest and dlc directories?
# Override with -s.
$SRCDIR = "..";

# Where is the handin directory? 
# Override with -d.
$HANDINDIR = "./handin";



