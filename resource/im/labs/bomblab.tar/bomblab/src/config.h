/*
 * config.h - configuration info for the bomb's email notification option
 *
 * To enable email notification, you will need to define NOTIFY when you 
 * compile the bomb's support.c file (see Makefile).
 */

/* 
 * Modify these three lines to control where and how notification occurs.
 * The notification option sends an email message to BOMB_USER@BOMB_HOST
 * whenever a bomb phase is defused or explodes. The email message is sent 
 * using the command: SENDMAIL BOMB_USER@BOMB_HOST. Sendmail is in /usr/sbin
 * on Linux systems, and /usr/lib on Solaris systems.
 */
#define BOMB_USER "bomb"
#define BOMB_HOST "bluegill.cmcl.cs.cmu.edu"
#define SENDMAIL  "/usr/sbin/sendmail -bm"

/* 
 * Modify this line to point to some well-known Web server. When a bomb
 * compiled with the notification option starts up, it verifies that
 * the machine is connected to the network by opening and closing an HTTP
 * connection to the following Web server:
 */
#define WEBSERVER "www.yahoo.com"

/*
 * We don't want copies of bombs from all over the world sending us email, 
 * so restrict bomb execution to one of the machines on the following 
 * NULL-terminated list:
 */
char *host_table[MAX_LINE] = {
    "bass.cmcl.cs.cmu.edu",
    "bluegill.cmcl.cs.cmu.edu",
    "char.cmcl.cs.cmu.edu",
    "chum.cmcl.cs.cmu.edu",
    "flier.cmcl.cs.cmu.edu",
    "gobi.cmcl.cs.cmu.edu",
    "grayling.cmcl.cs.cmu.edu",
    "inconnu.cmcl.cs.cmu.edu",
    "minnow.cmcl.cs.cmu.edu",
    "muskie.cmcl.cs.cmu.edu",
    "paddlefish.cmcl.cs.cmu.edu",
    "perch.cmcl.cs.cmu.edu",
    "pickerel.cmcl.cs.cmu.edu",
    "pike.cmcl.cs.cmu.edu",
    "pumpkinseed.cmcl.cs.cmu.edu",
    "salmon.cmcl.cs.cmu.edu",
    "sauger.cmcl.cs.cmu.edu",
    "shad.cmcl.cs.cmu.edu",
    "sheepshead.cmcl.cs.cmu.edu",
    "sockeye.cmcl.cs.cmu.edu",
    "striper.cmcl.cs.cmu.edu",
    "sturgeon.cmcl.cs.cmu.edu",
    "walleye.cmcl.cs.cmu.edu",
    "warmouth.cmcl.cs.cmu.edu",
    "whitefish.cmcl.cs.cmu.edu",
    0 /* The zero terminates the list */
};






