/*
 * support.c - Helper functions for the bomb
 *
 * Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.
 * May not be used, modified, or copied without permission.
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <time.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "support.h"
#include "config.h"

/* Global lab and bomb IDs defined by phases.c */
extern int bomb_id;
extern char lab_id[];

/* Global input stream defined by bomb.c */
extern FILE *infile;

/* Global that keeps track of the user's input strings */
char input_strings[MAX_STRINGS][MAX_LINE];
int num_input_strings = 0;

/* Global scratch buffer */
char scratch[MAX_LINE];

/******************************************************
 * Amusing signal handler called when user types ctrl-c
 ******************************************************/

static void sig_handler(int sig)
{
    printf("So you think you can stop the bomb with ctrl-c, do you?\n");
    sleep(3);
    printf("Well...");
    fflush(stdout);
    sleep(1);
    printf("OK. :-)\n");
    exit(16);
}

/************************************************** 
 * Helper routines called by the phases in phases.c
 **************************************************/

/* Invoked by improperly built phases */
void invalid_phase(char *s) 
{
    printf("Invalid phase%s\n", s);
    exit(8);
}

/* Extract numbers from an input string */
 void read_six_numbers(char *input, int *numbers)
{
  int numScanned = sscanf(input, "%d %d %d %d %d %d",
			  numbers, numbers + 1, numbers + 2,
			  numbers + 3, numbers + 4, numbers + 5);
  if (numScanned < 6)
    explode_bomb();
}

/* A more user-friendly version of strlen */
int string_length(char *aString)
{
    int length;
    char *ptr;

    ptr = aString;
    length = 0;

    while (*ptr != 0) {
	ptr++;
	length = length + 1;
    }
    return length;
}

/* A more user-friendly version of strcmp */
int strings_not_equal(char *string1, char *string2)
{
    char *p, *q;

    if (string_length(string1) != string_length(string2))
	return 1;

    p = string1;
    q = string2;

    while (*p != 0) {
	if (*p != *q)
	    return 1;
	p++;
	q++;
    }
    return 0;
}


/***********************************
 * Helper functions called by bomb.c  			 
 ***********************************/

/*
 * open_clientfd - open connection to server at <hostname, port> 
 *   and return a socket descriptor ready for reading and writing.
 */
int open_clientfd(char *hostname, int port) 
{
    int clientfd;
    struct hostent *hp;
    struct sockaddr_in serveraddr;

    if ((clientfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	printf("Bad host (1).\n");
	exit(8);
    }

    /* fill in the server's IP address and port */
    if ((hp = gethostbyname(hostname)) == NULL) {
	printf("Bad host (2).\n");
	exit(8);
    }

    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    bcopy((char *)hp->h_addr, 
	  (char *)&serveraddr.sin_addr.s_addr, hp->h_length);
    serveraddr.sin_port = htons(port);

    /* establish a connection with the server */
    if (connect(clientfd, (struct sockaddr *) &serveraddr, 
		sizeof(serveraddr)) < 0) {
	printf("Bad host (3).\n");
	exit(8);
    }
  
    return clientfd;
}

/* initialize the bomb */
void initialize_bomb(void)
{
#ifdef NOTIFY
    int i;
    char hostname[MAXHOSTNAMELEN];
    int valid_host = 0;
#endif

    /* Just for fun, trap Ctrl-C: */
    signal(SIGINT, sig_handler);
    
#ifdef NOTIFY

    /* Get the host name of the machine */
    if (gethostname(hostname, MAXHOSTNAMELEN) != 0) {
	printf("Bad host (4)\n");
	exit(8);
    }

    /* Make sure it's in the list of legal machines */
    for (i = 0; host_table[i]; i++) {
	if (strcasecmp(host_table[i], hostname) == 0) {
	    valid_host = 1;
	    break;
	}
    }
    if (!valid_host) {
	printf("Bad host (5).\n");
	exit(8);
    }

    /* Make sure the host is on the net */
   close(open_clientfd(WEBSERVER, 80));
#endif
}


/* return true if str is a blank line */
int blank_line(char *str)
{
    while (*str)
	if (!isspace(*str++))
	    return 0;
    return 1;
}

/* Read input lines until first non-blank or EOF encountered */
char *skip() 
{
    char *p;

    while (1) {
	p = fgets(input_strings[num_input_strings], MAX_LINE, infile);
	if ((p == NULL) || (!blank_line(p)))
	    return p;
    }
}

/* 
 * Read a line of input from stream "infile". There are a couple
 * of tricky aspects to this. First, we cut the students a little slack
 * by skipping over blank lines. Second, we allow partial solutions
 * to be read from a file before switching over to stdin.
 */
char *read_line(void)
{
    int len;
    char *str;

    /* switch over to stdin if we hit EOF on an input disk file */
    str = skip();
    if (str == NULL) { /* EOF */
	if (infile == stdin) { /* premature EOF on stdin */
	    printf("Error: Premature EOF on stdin\n");
	    explode_bomb();
	}
	else {
	    /* exit with OK status on EOF if we are grading the bomb */
	    /* this lets us evaluate partial solutions */
	    if (getenv("GRADE_BOMB")) {
		exit(0); 
	    }

	    /* otherwise switch over to stdin */
	    else {
		infile = stdin; 
		str = skip();
		if (str == NULL) { /* premature EOF on stdin */
		    printf("Error: Premature EOF on stdin\n");
		    explode_bomb();
		}
	    }
	}
    }

    len = strlen(input_strings[num_input_strings]);
    if(len == MAX_LINE-1) {
	printf("Error: Input line too long\n");
	explode_bomb();
    }

    /* Strip off trailing newline: */
    input_strings[num_input_strings][len-1] = '\0';
    return input_strings[num_input_strings++];
}


void send_msg(int defused)
{
    FILE *tmp;
    int i;
    char *userid;
    char useridbuf[MAX_LINE];
    int tmpstdin;

    /* Duplicate stdin in tmpstdin */
    if ((tmpstdin = dup(0)) == -1) {
	printf("ERROR: dup(0) error\n");
	exit(8);
    }	

    /* Close stdin (no problem, we just dup()'d it) */
    if (close(0) == -1) {
	printf("ERROR: close error\n");
	exit(8);
    }

    /* Open a temporary file with file descriptor 0 */
    if ((tmp = tmpfile()) == NULL) {
	printf("ERROR: tmpfile error\n");
	exit(8);
    }

    /* Emit the message that will be input to sendmail */
    fprintf(tmp, "Subject: Bomb notification\n");
    fprintf(tmp, "\n");

    /* Header line in body summarizes the bomb event */
    userid = (char *)cuserid(NULL);
    if (userid == NULL)
	strcpy(useridbuf, "nobody");
    else
	strcpy(useridbuf, userid);
    fprintf(tmp, "bomb-header:%s:%d:%s:%s:%d\n", lab_id, bomb_id, useridbuf, 
	    defused ? "defused" : "exploded", num_input_strings); 

    /* Followed by all of the input lines entered to this point */
    for (i = 0; i < num_input_strings; i++) {
	fprintf(tmp, "bomb-string:%s:%d:%s:%d:%s\n", 
		lab_id, bomb_id, useridbuf, i+1, input_strings[i]);
    }
    rewind(tmp);

    /* Send the email notification. The message body comes
     * from the tmp file (which sendmail thinks is stdin */
    sprintf(scratch, "%s %s@%s", SENDMAIL, BOMB_USER, BOMB_HOST);
    if (system(scratch) != 0) {
	printf("ERROR: notification error\n");
	exit(8);
    }

    /* clean up the open files */
    if (fclose(tmp) != 0) {
	printf("ERROR: fclose(tmp) error\n");
	exit(8);
    }

    /* dup stdin again so the stdin file table reference
     * count doesn't go to zero when we close tmpstdin */
    if (dup(tmpstdin) != 0) {
	printf("ERROR: dup(tmpstdin) error\n");
	exit(8);
    }

    if (close(tmpstdin) != 0) {
	printf("ERROR: close(tmpstdin)\n");
	exit(8);
    }
}

void explode_bomb(void)
{
    printf("\nBOOM!!!\n");
    printf("The bomb has blown up.\n");
#ifdef NOTIFY
    send_msg(0);
    printf("Your instructor has been notified.\n");
#endif 

    exit(8);
}

void phase_defused(void)
{
    char passphrase[MAX_LINE];
    int temp, numScanned;

#ifdef NOTIFY
    send_msg(1);
#endif

    if (num_input_strings == 6) { /* user has just defused phase 6 */
	numScanned = sscanf(input_strings[3], "%d %s", &temp, passphrase);
	if ((numScanned == 2) && 
	    (strings_not_equal(passphrase, SECRET_PHRASE) == 0)) {
	    printf("Curses, you've found the secret phase!\n");
	    printf("But finding it and solving it are quite different...\n");
	    secret_phase();
	}
	printf ("Congratulations! You've defused the bomb!\n");
#ifdef NOTIFY
	printf("Your instructor has been notified and will verify your solution.\n");
#endif	
    }
}

