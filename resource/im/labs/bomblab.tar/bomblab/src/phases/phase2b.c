/* 
 * phase2b.c - To defeat this stage the user must enter arithmetic 
 * sequence of length 6 and delta = 5. 
 */
void phase_2(char *input)
{
#if defined(PROBLEM)
    int ii;
    int numbers[6];
    
    read_six_numbers(input, numbers);
    
    for(ii = 1; ii < 6; ii++) {
	if (numbers[ii] != numbers[ii-1] + 5)
	    explode_bomb();
    }
#elif defined(SOLUTION)
    printf("1 6 11 16 21 26\n");
#else
    invalid_phase("2b");
#endif
}
