/* 
 * phase6a.c - The user has to enter a number that, when the list is sorted, 
 * will show up in the proper position (chosen at random).
 */
listNode node9 = {POSITIVE, 9, NULL};
listNode node8 = {POSITIVE, 8, &node9};
listNode node7 = {POSITIVE, 7, &node8};
listNode node6 = {POSITIVE, 6, &node7};
listNode node5 = {POSITIVE, 5, &node6};
listNode node4 = {POSITIVE, 4, &node5};
listNode node3 = {POSITIVE, 3, &node4};
listNode node2 = {POSITIVE, 2, &node3};
listNode node1 = {POSITIVE, 1, &node2};
listNode node0 = {0, 0, &node1};

listNode *fun6(listNode *start)
{
    listNode *head = start;
    listNode *p, *q, *r;

    head = start;
    p = start->next;
    head->next = NULL;

    while (p != NULL) {
	r = head;
	q = head;

	while ((r != NULL) && (r->value > p->value)) {
	    q = r;
	    r = r->next;
	}

	if (q != r)
	    q->next = p;
	else
	    head = p;

	q = p->next;
	p->next = r;

	p = q;
    }

    return head;
}

void phase_6(char *input)
{
    int i;
    listNode *start = &node0;
    listNode *p;

#if defined(PROBLEM)
    start->value = atoi(input);
#elif defined(SOLUTION)
    start->value = 0;
#endif

    /* Sort */
    start = fun6(start);

#if defined(PROBLEM)
    /* Check */
    p = start;
    for (i = 1; i < PLACE_IN_LIST_SET; i++)  {
	p = p->next;
    }
    if (p->value != node0.value)
	explode_bomb();
#elif defined(SOLUTION)
    p = start;
    for (i = 1; i < PLACE_IN_LIST_GET; i++)  {
	p = p->next;
    }
    printf("%d\n", p->value);
#else
    invalid_phase("6a");
#endif
}
