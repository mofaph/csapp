/* 
 * phase6c.c - Given a linked list of 9 nodes, the user has to enter the value
 * in the node that is in the kth place after sorting (where k is
 * generated randomly).
 */
listNode node9 = {POSITIVE, 9, NULL};
listNode node8 = {POSITIVE, 8, &node9};
listNode node7 = {POSITIVE, 7, &node8};
listNode node6 = {POSITIVE, 6, &node7};
listNode node5 = {POSITIVE, 5, &node6};
listNode node4 = {POSITIVE, 4, &node5};
listNode node3 = {POSITIVE, 3, &node4};
listNode node2 = {POSITIVE, 2, &node3};
listNode node1 = {POSITIVE, 1, &node2};

listNode *fun6(listNode *start)
{
    listNode *head = start;
    listNode *p, *q, *r;

    head = start;
    p = start->next;
    head->next = NULL;

    while (p != NULL) {
	r = head;
	q = head;

	while ((r != NULL) && (r->value > p->value)) {
	    q = r;
	    r = r->next;
	}

	if (q != r)
	    q->next = p;
	else
	    head = p;

	q = p->next;
	p->next = r;

	p = q;
    }

    return head;
}

void phase_6(char *input)
{
#if defined(PROBLEM)
    int i;
    int value;
    listNode *start = &node1;
    listNode *p;

    value = atoi(input);

    /* Sort */
    start = fun6(start);

    /* Find kth node in list, and compare it's value with input value */
    p = start;
    i = 1;
    while (i != PLACE_IN_LIST_SET) {
	p = p->next;
	i++;
    }

    if (p->value != value)
	explode_bomb();
#elif defined(SOLUTION)
    int i;
    listNode *start = &node1;
    listNode *p;

    /* Sort */
    start = fun6(start);

    i = 1;
    p = start;
    while (i != PLACE_IN_LIST_GET) {
	p = p->next;
	i++;
    }
    printf("%d\n", p->value);
#else
    invalid_phase("6c");
#endif
}




