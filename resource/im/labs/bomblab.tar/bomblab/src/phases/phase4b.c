/* 
 * phase4b.c - A recursive function to sort out. 
 * Computes powers of 7, must match the power of 7 randomly generated. 
 */
#if defined(PROBLEM)
int func4(int i) {
    if (i <= 0) {
	return 1;
    }
    return 7 * func4(i - 1);
}
#elif defined(SOLUTION)
/* given y = 7^x , return x */
int func4_inverse(int y) {
    switch (y) {
    case 49: return 2;
    case 343 : return 3; 
    case 2401: return 4;
    case 16807: return 5; 
    case 117649: return 6; 
    case 823543: return 7; 
    case 5764801: return 8; 
    default:
	fprintf(stderr, "ERROR: bad input in phase4b\n");
	exit(8);
    }
}
#endif

void phase_4(char *input) {
#if defined(PROBLEM)
    int result, val, numScanned = sscanf(input, "%d", &val);

    if((numScanned != 1) || (val < 1)) {
	explode_bomb();
    }

    result = func4(val);

    if(result != GEOM_NUMBER_SET) {
	explode_bomb();
    }
#elif defined(SOLUTION)
    printf("%d %s\n", func4_inverse(GEOM_NUMBER_GET), SECRET_PHRASE);
#else
    invalid_phase("4b");
#endif
}
