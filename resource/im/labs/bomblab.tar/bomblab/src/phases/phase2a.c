/* 
 * phase2a.c - To defeat this stage the user must enter a sequence of 
 * 6 factorial numbers  starting with 1.
 */
void phase_2(char *input)
{
#if defined(PROBLEM)
    int ii;
    int numbers[6];

    read_six_numbers(input, numbers);

    if (numbers[0] != 1)
	explode_bomb();

    for(ii = 1; ii < 6; ii++) {
	if (numbers[ii] != (numbers[ii - 1] * (ii+1)))
	    explode_bomb();
    }
#elif defined(SOLUTION)
    printf("1 2 6 24 120 720\n");
#else
    invalid_phase("2a");
#endif
}
