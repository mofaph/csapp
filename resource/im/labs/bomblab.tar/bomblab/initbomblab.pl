#!/usr/local/bin/perl 
use Getopt::Std;

#######################################################################
# initbomblab - initializes the bomb lab
#
# Copyright (c) 2003, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
# This script initializes the bomb lab. It ensures that the necessary
# scripts are present and executable, removes the log file for the
# request daemon, and checks the email spool file has the proper 
# name and ownership.
#
# Run this script once,  prior to starting the lab with "make start"
#######################################################################

$BOMBDIR = "bombs";
$REPORTD = "bomb-reportd.pl"; 
$REQUESTD = "bomb-requestd.pl";

$RERUNMSG = "Then rerun \"make init\""; 

$| = 1; # autoflush output on every print statement

$rerun = 'Then rerun the "make init" command.';

#
# usage - print help message and terminate
#
sub usage 
{
    printf STDERR "$_[0]\n";
    printf STDERR "Usage: $0 [-h] -s <spoolfile>\n";
    printf STDERR "Options:\n";
    printf STDERR "  -h             Print this message\n";
    printf STDERR "  -s <spoolfile> Absolute pathname of the bomb mail spool file.\n";
    die "\n";
}

# 
# Parse and check the command line arguments
#
getopts('hs:');
if ($opt_h) {
    usage();
}
($spoolfile = $opt_s) 
    or usage("Missing required mail spool file argument (-s)");

#
# If the spool file is called "bomb" (associated with user bomb)
#
$spoolfile =~ /.*\/(\w+$)/;
$suffix = $1;

#
# ... then it should be owned by bomb
#
$lsout = `ls -l $spoolfile`;
($tmp1, $tmp2, $owner, $rest) = split(" ", $lsout);
($owner eq $suffix)
    or die "$0: ERROR: The mail spool file should owned by $suffix rather than $owner\n";


#
# Make sure there is an empty directory for newly created bombs.
#
if (-e $BOMBDIR) {
    die "$0: ERROR. There is an existing bomb directory ($BOMBDIR).\nDelete or rename it. $RERUNMSG\n"; 
    system("rm -rf $BOMBDIR/bomb*");
}
else {
    system("mkdir $BOMBDIR") == 0
	or die "$0: ERROR: Couldn't create $BOMBDIR\n";
}

#
# Make sure the reporting and requesting daemons exist and are executable
#
(-e "./$REPORTD" and -x "./$REPORTD")
    or die "$0: ERROR: the ./$REPORTD script either does not exist or is not executable.\nFix the permissions. $RERUNMSG\n";

(-e "./$REQUESTD" and -x "./$REQUESTD")
    or die "$0: ERROR: the ./$REQUESTD script either does not exist or is not executable.\nFix the permissions. $RERUNMSG\n";


#
# Delete the request daemon log file
#
system("rm -f requestd.log");

exit;



