#!/usr/bin/perl 
#!/usr/local/bin/perl 
use Getopt::Std;

$SLEEP = 10;   # secs to sleep between spool file sweeps

#######################################################################
# bomb-reportd.pl - Binary bomb reporting daemon
#
# Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
# Repeatedly calls on the grade-bomblab.pl script to report 
# defusion/explosion statistics for each bomb. Can optionally
# be asked to validate each bomb each iteration.
#
#######################################################################

$| = 1; # autoflush output on every print statement

#
# usage - print help message and terminate
#
sub usage 
{
    printf STDERR "$0: ERROR: $_[0]\n";
    printf STDERR "Usage: $0 [-hv] -l <labid> -a <autograder> -b <bombdir> -s <spoolfile> -w <webpage>\n";
    printf STDERR "Options:\n";
    printf STDERR "  -h            Print this message\n";
    printf STDERR "  -a <grader>   Location of autograder\n"; 
    printf STDERR "  -b <bombdir>  Directory where bombs are stored\n";
    printf STDERR "  -l <labid>    Unique arbitrary name for this lab\n";
    printf STDERR "  -s <file>     email spool file\n";
    printf STDERR "  -w <file>     Output Web page\n";
    printf STDERR "  -v            Validate each solution (default no)\n";
    die "\n";
}

##############
# Main routine
##############

# 
# Parse and check the command line arguments
#
getopts('hvs:l:w:a:b:');
if ($opt_h) {
    usage();
}
$labid = $opt_l
    or usage("Missing lab ID argument (-l)\n");
$spoolfile = $opt_s
    or usage("Missing spool file argument (-s)\n");
$bombdir = $opt_b
    or usage("Missing bomb directory argument (-b)\n");
$webpage = $opt_w
    or usage("Missing output Web page argument (-w)\n");
$autograder = $opt_a
    or usage("Missing autograder argument (-a)\n");

# Check that the autograder exists 
# (the autograder will check the validity of the other args)
-e $autograder and -x $autograder
    or die "$0: ERROR: Autograder ($autograder) either missing or not executable\n";

# Set the optional args
$validate = $opt_v;

#
# Warn if there is another reporting process running
#
$ps = `ps -e`;     # get a list of all processes 
$ps =~ s/0//;      # elide this one from the proc list
if ($ps =~ /$0/) { # print a warning if there is another one
    warn "\n$0: WARNING: There appears to be another $0 process running.\n";
}

#
# Repeatedly call the grade bomblab script to scan the spool file
# validate the bombs, and update the web page. 
#
while (1) {
    #call autograder in quiet mode, with validation
    system("$autograder -q -v -l $labid -b $bombdir -s $spoolfile -w $webpage") == 0
	or warn "$0: ERROR: $autograder failed\n";

    # Sleep a bit and then do it all over again
    sleep($SLEEP);
}

# Control never actually reaches here
exit;
