#!/usr/bin/perl
#!/usr/local/bin/perl
require 5.002;
use Getopt::Std;
use Socket;
use Sys::Hostname; 

#######################################################################
# bomb-requestd.pl - The CS:APP Binary Bomb Request Daemon
#
# The request daemon is a special purpose HTTP server that allows 
# students to request binary bombs using their Web browser.
#
# Students request a bomb in two steps:
#
# 1. Form request: First, a student gets a bomb request form 
#    by pointing their browser at the host and port of the request daemon 
#    (e.g., http://foo.cs.cmu.edu:51231).  The request daemon then 
#    sends an HTML form back to the browser.
# 
# 2. Bomb request: Second, the student fills in the form with the
#    team member information and then submits the form. After the
#    server receives the bomb request, it parses the URI in the request
#    to extract the identities of the team members, builds a custom 
#    bomb for the team, tars it up and returns the tar file to the browser.
#
# Copyright (c) 2003, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
#######################################################################

#
# Key directories and scripts
#
$MAKEBOMB = "./makebomb.pl";  # location of makebomb script
$BOMBSRC = "./src";           # location of bomb source files
$BOMBDIR = "./bombs";         # directory that contains newly created bombs

#
# Canned client error messages
#
$bad_user1mail_msg = "You forgot to type an email address for team member 1.";
$bad_user1name_msg = "You forgot to type a name for team member 1.";
$bad_user2name_msg = "You typed an email address for team member 2, but forgot the name.";
$missing_user2mail_msg = "You typed a name for team member 2, but forgot the email address.";

$user1mail_taint_msg = "The email address for team member 1 contains an illegal character.";
$user1name_taint_msg = "The name field for team member 1 contains an illegal character.";
$user2mail_taint_msg = "The email address for team member 2 contains an illegal character.";
$user2name_taint_msg = "The name field for team member 2 contains an illegal character.";

# 
# Autoflush output on every print statement
#
$| = 1; 

# 
# Ignore any SIGPIPE signals caused by the server writing 
# to a connection that has already been closed by the client
#
$SIG{PIPE} = 'IGNORE'; 

###################
# Helper functions
##################

#
# void usage(void) - print help message and terminate
#
sub usage 
{
    printf STDERR "$_[0]\n";
    printf STDERR "Usage: $0 [-hq] -l <labid> -p <port>\n";
    printf STDERR "Options:\n";
    printf STDERR "  -h          Print this message.\n";
    printf STDERR "  -l <labid>  Unique arbitrary name for this Lab.\n";
    printf STDERR "  -p <port>   Port to listen on for bomb requests.\n";
    printf STDERR "  -q          Quiet. Build bombs with NONOTIFY option.\n";
    die "\n" ;
}

#
# void logmsg(char *msg) - prints a log message
#
sub logmsg 
{
    print scalar localtime, ":@_\n";
}

#
# char *buildform(char *hostname, int port, char *labid, 
#                 char *user1mail, char *user1name,
#                 char *user2mail, char *user2name, 
#                 *char *errmsg)
#
# This routine builds an HTML form as a single string.
# The <hostname,port> pair identifies the request daemon.
# The labid is the unique name for this instance of the Lab.
# The user* fields define the default values for the HTML form fields. 
# The errmsg is optional and informs users about input mistakes.
#
sub buildform 
{
    my $hostname = $_[0];
    my $port = $_[1];
    my $labid = $_[2];
    my $user1mail = $_[3];
    my $user1name = $_[4];
    my $user2mail = $_[5];
    my $user2name = $_[6];
    my $errmsg = $_[7];
    my $form = "";
    $form .= "<html><title>CS:APP Binary Bomb Request - $labid</title>\n";
    $form .= "<body bgcolor=white>\n";
    $form .= "<h2>CS:APP Binary Bomb Request - $labid</h2>\n";
    $form .= "<p>Fill in the information about\n";
    $form .= "your team and then click the Submit button.</p>\n";
    $form .= "<p>Hit the Reset button to get a clean form.</p>\n";
    $form .= "<p>For security reasons, the only legal characters are spaces,\n";
    $form .= "letters, numbers,<br>underscores ('_'), hyphens ('-'), \n";
    $form .= "at signs ('\@'), and dots ('.').</p>\n";
    $form .= "<form action=http://$hostname:$port method=get>\n";
    $form .= "<table>\n";
    $form .= "<tr>\n";
    $form .= "<td> Team member 1 email address (required):</td>\n";
    $form .= "<td><input type=text size=32 name=user1mail value=\"$user1mail\"></td>\n";
    $form .= "</tr>\n";
    $form .= "<tr>\n";
    $form .= "<td> Team member 1 full name (required):</td>\n";
    $form .= "<td><input type=text size=32 name=user1name value=\"$user1name\"></td>\n";
    $form .= "</tr>\n";
    $form .= "<p>\n";
    $form .= "<tr>\n";
    $form .= "<td>Team member 2 email address (optional):</td>\n";
    $form .= "<td><input type=text size=32 name=user2mail value=\"$user2mail\"></td>\n";
    $form .= "</tr>\n";
    $form .= "<tr>\n";
    $form .= "<td>Team member 2 full name (optional):</td>\n";
    $form .= "<td><input type=text size=32 name=user2name value=\"$user2name\"></td>\n";
    $form .= "</tr>\n";
    $form .= "<tr></tr>\n";
    $form .= "<tr>\n";
    $form .= "<td><input type=submit name=submit value=\"Submit\"></td>\n";
    $form .= "<td><input type=submit name=reset value=\"Reset\"></td>\n";
    $form .= "</tr>\n";
    $form .= "</table></form>\n";
    if ($errmsg and $errmsg ne "") {
	$form .= "<p><font color=red><b>$errmsg</b></font><p>\n";
    }
    $form .= "</body></html>\n";
    return $form;
}

#
# void sendform(char *form) - Sends a form to the client   
#
sub sendform
{
    my $form = $_[0];
    my $formlength = length($form);
    print CLIENT "HTTP/1.0 200 OK\r\n";
    print CLIENT "MIME-Version: 1.0\r\n";
    print CLIENT "Content-Type: text/html\r\n";
    print CLIENT "Content-Length: $formlength\r\n";
    print CLIENT "\r\n"; 
    print CLIENT $form;
}

##############
# Main routine
##############

# 
# Parse and check the command line arguments
#
getopts('hqp:l:');
if ($opt_h) {
    usage("");
}

$labid = $opt_l
    or usage("Missing lab ID argument (-l)");

$server_port = $opt_p
    or usage("Missing port number (-p)");

$notifyflag = "-n";
if ($opt_q) {
    $notifyflag = "";
}

#
# Warn if there is another bomb-requestd process running
#
$ps = `ps -e`;
$ps =~ s/$0//;
if ($ps =~ /$0/) {
    warn "\n$0: WARNING: There appears to be another $0 daemon running.\n";
}

#
# Make sure the files and directories we need are available
#
(-e $MAKEBOMB and -x $MAKEBOMB)
    or die "$0: ERROR: Couldn't find an executable $MAKEBOMB script.\n";

(-e $BOMBDIR)
    or die "$0: ERROR: Bomb directory ($BOMBDIR) does not exist. Have you intialized the lab with \"make init\"?\n";
  
#
# Establish a listening descriptor
# 
socket(SERVER, PF_INET, SOCK_STREAM, getprotobyname('tcp'))
    or die "socket: $!\n";
setsockopt(SERVER, SOL_SOCKET, SO_REUSEADDR, 1)
    or die "setsockopt: $!\n";
bind(SERVER, sockaddr_in($server_port, INADDR_ANY))
    or die "Couldn't bind to port $server_port: $!\n";
listen(SERVER, SOMAXCONN)     
    or die "listen: $!\n";


$server_dname = hostname();
logmsg "Server started on $server_dname:$server_port";


#
# Repeatedly wait for form and bomb requests
#
while (1) {

    # 
    # Wait for a connection request from a client
    #
    my $client_paddr = accept(CLIENT, SERVER)
	or die "accept: $!\n";
    ($client_port, $client_iaddr) = sockaddr_in($client_paddr);
    $client_dname = gethostbyaddr($client_iaddr, AF_INET);

    # 
    # Read the request header (the first text line in the request)
    #
    $request_hdr = <CLIENT>;
    chomp($request_hdr);

    # 
    # If there aren't any specific HTML form arguments, then we interpret
    # this as an initial request for an HTML form. So we build the 
    # form and send it back to the client.
    #
    if (!($request_hdr =~ /user1mail=/)) {
	logmsg ("Form request from $client_dname [", 
		inet_ntoa($client_iaddr), "]");
	sendform(buildform($server_dname, $server_port, $labid, 
			   "", "", "", "", ""));
    }

    #
    # If this is a reset request, just send the client a clean form
    #
    elsif ($request_hdr =~ /reset=/) {
	logmsg ("Reset request from $client_dname [", 
		inet_ntoa($client_iaddr), "]");
	sendform(buildform($server_dname, $server_port, $labid, 
			   "", "", "", "", ""));
    }

    # 
    # Otherwise, since it's not a reset (clean form) request and the URI contains a 
    # specific HTML form argument, we interpret this as a bomb request. 
    # So we parse the URI, build the bomb, tar it up, and transfer it back over the 
    # connection to the client.
    # 
    else {
	#
        # Undo the browser's URI translations of special characters
	#
	$request_hdr =~ s/%25/%/g;  # Do first to handle %xx inputs

	$request_hdr =~ s/%20/ /g; 
	$request_hdr =~ s/\+/ /g; 
	$request_hdr =~ s/%21/!/g;  
	$request_hdr =~ s/%23/#/g;  
	$request_hdr =~ s/%24/\$/g; 
	$request_hdr =~ s/%26/&/g;  
	$request_hdr =~ s/%27/'/g;    
	$request_hdr =~ s/%28/(/g;    
	$request_hdr =~ s/%29/)/g;    
	$request_hdr =~ s/%2A/*/g;    
	$request_hdr =~ s/%2B/+/g;    
	$request_hdr =~ s/%2C/,/g;    
	$request_hdr =~ s/%2D/-/g;    
	$request_hdr =~ s/%2d/-/g;    
	$request_hdr =~ s/%2E/./g;    
	$request_hdr =~ s/%2e/./g;    
	$request_hdr =~ s/%2F/\//g;    

	$request_hdr =~ s/%3A/:/g;    
	$request_hdr =~ s/%3B/;/g;    
	$request_hdr =~ s/%3C/</g;    
	$request_hdr =~ s/%3D/=/g;    
	$request_hdr =~ s/%3E/>/g;    
	$request_hdr =~ s/%3F/?/g;    

	$request_hdr =~ s/%40/@/g;

	$request_hdr =~ s/%5B/[/g;
	$request_hdr =~ s/%5C/\\/g;
	$request_hdr =~ s/%5D/[/g;
	$request_hdr =~ s/%5E/\^/g;
	$request_hdr =~ s/%5F/_/g;
	$request_hdr =~ s/%5f/_/g;

	$request_hdr =~ s/%60/`/g;

	$request_hdr =~ s/%7B/\{/g;
	$request_hdr =~ s/%7C/\|/g;
	$request_hdr =~ s/%7D/\}/g;
	$request_hdr =~ s/%7E/~/g;


	# Parse the request URI to get the user information
        print "hdr:$request_hdr:\n";

	$request_hdr =~     
	    /user1mail=(.*)&user1name=(.*)&user2mail=(.*)&user2name=(.*)&/;
	$user1mail = $1;
	$user1name = $2;
	$user2mail = $3;
	$user2name = $4;

	#
	# For security purposes, make sure the form inputs contain only 
        # non-shell metacharacters. The only legal characters are spaces, 
	# letters, numbers, hyphens, underscores, at signs, and dots.
	#

        # user1 mail field
	if ($user1mail ne "") {
	    if (!($user1mail =~ /^([\s-\@\w.]+)$/)) {
		logmsg ("Invalid bomb request from $client_dname [", 
			inet_ntoa($client_iaddr), 
			"]:Illegal character in user1 mail address ($user1mail):"); 
		sendform(buildform($server_dname, $server_port, $labid, 
				   $user1mail, $user1name, 
				   $user2mail, $user2name, 
				   $user1mail_taint_msg));
		close CLIENT;
		next;
	    }
	}

	# user1 name field
	if ($user1name ne "") {
	    if (!($user1name =~ /^([\s-\@\w.]+)$/)) {
		logmsg ("Invalid bomb request from $client_dname [", 
			inet_ntoa($client_iaddr), 
			"]:Illegal character in user1 name ($user1name):"); 
		sendform(buildform($server_dname, $server_port, $labid, 
				   $user1mail, $user1name, 
				   $user2mail, $user2name, 
				   $user1name_taint_msg));
		close CLIENT;
		next;
	    }
	}

	# user2 mail field
	if ($user2mail ne "") {
	    if (!($user2mail =~ /^([\s-\@\w.]+)$/)) {
		logmsg ("Invalid bomb request from $client_dname [", 
			inet_ntoa($client_iaddr), 
			"]:Illegal character in user2 mail address ($user2mail):"); 
		sendform(buildform($server_dname, $server_port, $labid, 
				   $user1mail, $user1name, 
				   $user2mail, $user2name, 
				   $user2mail_taint_msg));
		close CLIENT;
		next;
	    }
	}

	# user2 name field
	if ($user2name ne "") {
	    if (!($user2name =~ /^([\s-\@\w.]+)$/)) {
		logmsg ("Invalid bomb request from $client_dname [", 
			inet_ntoa($client_iaddr), 
			"]:Illegal character in user2 name ($user2name):"); 
		sendform(buildform($server_dname, $server_port, $labid, 
				   $user1mail, $user1name, 
				   $user2mail, $user2name, 
				   $user2name_taint_msg));
		close CLIENT;
		next;
	    }
	}

	#
	# The first user mail field is required. If it's not filled in,
	# or it's all blanks, then it's invalid
	#
	if (!$user1mail or $user1mail eq "" or $user1mail =~ /^ +$/) {
	    logmsg ("Invalid bomb request from $client_dname [", 
		    inet_ntoa($client_iaddr), 
		    "]:Invalid user1 mail address ($user1mail):"); 

  	    sendform(buildform($server_dname, $server_port, $labid, 
			       $user1mail, $user1name, 
			       $user2mail, $user2name, 
			       $bad_user1mail_msg));
	    close CLIENT;
	    next;
	}

	# The first user name field is also required. If it's not filled in,
	# or it's all blanks, then it's invalid
	if (!$user1name or $user1name eq "" or $user1name =~ /^ +$/) {
	    logmsg ("Invalid bomb request from $client_dname [", 
		    inet_ntoa($client_iaddr), 
		    "]:Missing user1 name:");

  	    sendform(buildform($server_dname, $server_port, $labid, 
			       $user1mail, $user1name, 
			       $user2mail, $user2name, 
			       $bad_user1name_msg)); 
	    close CLIENT;
	    next;
	}

	# The second user name field is not required, but if the corresponding
	# mail field is filled in, then the name field must be filled in too.
	if ($user2mail and $user2mail ne "" and !($user2mail =~ /^ +$/)
	    and ($user2name eq "" or $user2name =~ /^ +$/)) {
	    logmsg ("Invalid bomb request from $client_dname [", 
		    inet_ntoa($client_iaddr), 
		    "]:Missing user2 name:");

  	    sendform(buildform($server_dname, $server_port, $labid, 
			       $user1mail, $user1name, 
			       $user2mail, $user2name, 
			       $bad_user2name_msg)); 
	    close CLIENT;
	    next;
	}

	# The second user mail field is optional, but if the corresponding
	# name field is filled in, then the mail field must be filled in too. 
	if ($user2name and $user2name ne "" and !($user2name =~ /^ +$/)
	    and ($user2mail eq "" or $user2mail =~ /^ +$/)) {
	    logmsg ("Invalid bomb request from $client_dname [", 
		    inet_ntoa($client_iaddr), 
		    "]:Missing user2 mail address:");

  	    sendform(buildform($server_dname, $server_port, $labid, 
			       $user1mail, $user1name, 
			       $user2mail, $user2name, 
			       $missing_user2mail_msg)); 
	    close CLIENT;
	    next;
	}



	#
	# Everything checks out OK. So now we build and deliver the 
	# bomb to the client.
	# 
	logmsg ("Bomb request from $client_dname [", 
		inet_ntoa($client_iaddr), 
		"]:$user1mail:$user1name:$user2mail:$user2name:");
	
	# Get a list of all of the bombs in the bomb directory
	opendir(DIR, $BOMBDIR) 
	    or die "ERROR: Couldn't open $BOMBDIR\n";
	@bombs = grep(/bomb/, readdir(DIR)); 
	closedir(DIR);
	
	#
	# Find the largest bomb number, being careful to use numeric 
	# instead of lexicographic comparisons.
	#
	map s/bomb//, @bombs;
	$maxbombnum = 0;
	foreach $item (@bombs) {
	    if ($item > $maxbombnum) {
		$maxbombnum = $item;
	    }
	} 
	$bombnum = $maxbombnum + 1;
	
	#
	# Build a new bomb, being careful, for security reasons, 
	# to invoke the list version of system and thus avoid 
	# running a shell.
	#
	system("$MAKEBOMB", "$notifyflag", "-l", "$labid", "-i", "$bombnum", "-b", "$BOMBDIR", "-s", "$BOMBSRC", "-u", "$user1mail", "-v", "$user2mail") == 0 
	    or die "ERROR: Couldn't make bomb$bombnum\n";
	
	#
	# Tar up the bomb
	#
	$tarfilename = "bomb$bombnum.tar";
	system("(cd $BOMBDIR; tar cvf - bomb$bombnum/README bomb$bombnum/bomb bomb$bombnum/bomb.c > $tarfilename)") == 0 
	    or die "ERROR: Couldn't tar $tarfilename\n";
	
	#
	# Now send the bomb across the connection to the client
	#
	print CLIENT "HTTP/1.0 200 OK\r\n";
	print CLIENT "Connection: close\r\n";
	print CLIENT "MIME-Version: 1.0\r\n";
	print CLIENT "Content-Type: application/x-tar\r\n";
	print CLIENT "Content-Disposition: filename=\"$tarfilename\"\r\n";
	print CLIENT "\r\n"; 
	open(INFILE, "$BOMBDIR/$tarfilename")
	    or die "ERROR: Couldn't open $tarfilename\n";
	binmode(INFILE);
	while (read(INFILE, $buffer, 8*1024)) {
	    print CLIENT $buffer;
	}
	close(INFILE);
	
	# 
	# Log the successful delivery of the bomb to the browser
	#
	logmsg ("Delivered bomb $bombnum to $client_dname [", 
		inet_ntoa($client_iaddr), 
		"]:$user1mail:$user1name:$user2mail:$user2name:");
	
	# 
	# Remove the tarfile
	# 
	unlink("$BOMBDIR/$tarfilename")
	    or die "ERROR: Couldn't delete $tarfilename: $!\n";

    } # if () then form-request else bomb-request

    #
    # Close the client connection after each request/response pair
    #
    close CLIENT;

} # while loop

exit;
