#!/usr/bin/perl 
#!/usr/local/bin/perl 
use Getopt::Std;

$NUMPHASES = 6;   # number of phases (not counting secret phase)

#######################################################################
# makebomb.pl - Builds a CS:APP binary bomb.
#
# Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
#######################################################################

$| = 1; # autoflush output on every print statement

#
# usage - print help message and terminate
#
sub usage 
{
    printf STDERR "$_[0]\n";
    printf STDERR "Usage: $0 [-hn] -s <dir> -b <dir> -l <labid> [-i <bombid>] [-u <usr1>] [-v <usr2>] [-p <phases>]\n";
    printf STDERR "Options:\n";
    printf STDERR "  -b <bombdir> Output bomb directory (bomb goes in <bombdir>/bomb<bombid>)\n";
    printf STDERR "  -h           Print this message\n";
    printf STDERR "  -i <bombid>  Integer bomb id (default 0: generic bomb)\n";
    printf STDERR "  -l <labid>   Unique arbitrary name for this Lab\n";
    printf STDERR "  -n           Build a bomb with notification enabled (default: disabled)\n";
    printf STDERR "  -p <phases>  Specifies variant for each phase [-p abccba] (default: random)\n";
    printf STDERR "  -s <srcdir>  Directory that contains bomb sources\n";
    printf STDERR "  -u <usr1>    Login id of student 1 (required for custom bombs)\n";
    printf STDERR "  -v <usr2>    Login id of student 2 (default: none)\n";
    die "\n";
}

##############
# Main routine
##############

# 
# Parse and check the command line arguments
#
getopts('hnl:i:u:v:p:s:b:');
if ($opt_h) {
    usage();
}

if (!$opt_s) {
    usage("Required argument (-s) misssing");
}

if (!$opt_b) {
    usage("Required argument (-b) misssing");
}

$labid = $opt_l
    or usage("Required argument (-l) misssing");

#
# Do we want this bomb built with the notification option?
#
$notify = $opt_n;

#
# Every bomb gets a non-negative integer bomb ID 
#
if ($opt_i == NULL) {
    $opt_i = 0;
}
(($bombid = $opt_i) >= 0)
    or usage("Invalid bomb ID (-i)");

#
# A generic bomb is not associated with any student.
# A custom bomb must be associated with one or two students.
#
$studentid1 = $opt_u;
$studentid2 = $opt_v;
if ($bombid == 0 and $studentid1) {
    usage("A generic bomb must not be associated with a student (-u)");
}
if ($bombid > 0 and !$studentid1) {
    usage("A custom bomb must be associated with at least one student (-u)");
}

# 
# Get the location of the bomb src directory and make sure it exists
#
(($srcdir = $opt_s))
    or usage("Invalid src directory (-s $srcdir)");
(-e $srcdir) 
    or die "$0: ERROR: $srcdir does not exist\n";
(-d $srcdir) 
    or die "$0: ERROR: $srcdir is not a directory\n";

# 
# Get the directory where we will create the new bomb subdirectory
#
(($topbombdir = $opt_b))
    or usage("Invalid bomb directory (-b $topbombdir)");
(-e $topbombdir) 
    or die "$0: ERROR: $topbombdir does not exist\n";
(-d $topbombdir) 
    or die "$0: ERROR: $topbombdir is not a directory\n";

# 
# Get the optional request for a particular phase set
# If omitted, we'll generate a random phase set
#
if ($opt_p) {
    @phasearray = split(//, $opt_p);
    ((@phasearray == $NUMPHASES) and (($opt_p =~ tr/a-c//) == $NUMPHASES)) 
	or usage("Invalid phase pattern");
    $phases = $opt_p;
} 

# 
# Should we use random or predetermined phase variants?
# In either case, we will call makephases.pl (via src/Makefile)
# with explicit phase variants
#
if (!$phases) { # user has asked for random phase variants
    @list = ("a", "b", "c");
    for ($i=0; $i < $NUMPHASES; $i++) {
	$phasearray[$i] = $list[rand(@list)];
    }
    $phases = join("", @phasearray);
}
$phasearg = "-p $phases";

#
# Generic bombs (id=0) are not allowed to notify.
#
if ($notify and $bombid == 0) {
    usage("A generic bomb (-i 0) must not notify the instructor (-n)");
}

# 
# Create the directory that will hold the bomb files
#
$bombdir = $topbombdir."/bomb".$bombid;
(!(-e $bombdir)) 
    or die "$0: ERROR: $bombdir already exists\n";

system("mkdir $bombdir") == 0
    or die "$0: ERROR: Could not create $bombdir\n";

#
# Now go ahead and make the new bomb in the src directory
#

#
# Should the bomb notify the instructor on every explosion and defusion?
#
if ($notify) {
    $bombflags="-DNOTIFY";
    print "Making bomb$bombid with notification turned on.\n";
}
else {
    $bombflags="";
    print "Making bomb$bombid with notification turned off.\n";
}    

# 
# Remove all traces of previous bombs in the src directory
#
system("cd $srcdir; make -s cleanall") == 0
    or die "$0: ERROR: could not clean bomb source directory\n";

# 
# Now we're ready to make the bomb that will be sent to the student
#
system("(cd $srcdir; export BOMBFLAGS='$bombflags'; export BOMBPHASES='$phasearg'; export BOMBID=$bombid; export LABID=$labid; make -e bomb; make solution.txt)") == 0
    or die "$0: ERROR: could not make the bomb in $srcdir\n";

# 
# Make a quiet (non-notifying) version of the same bomb for validation
#
print "Making bomb$bombid with notification turned off.\n";
system("(cd $srcdir; rm -f *.o bomb-quiet; export BOMBFLAGS='-DNONOTIFY'; export BOMBPHASES='$phasearg'; export BOMBID=$bombid; export LABID=$labid; make -e bomb-quiet)") == 0
    or die "$0: ERROR: could not make the bomb in $srcdir\n";

#
# Copy the new bombs to the bomb directory
#
system("cp $srcdir/{bomb,bomb-quiet,bomb.c,phases.c,solution.txt} $bombdir") == 0
    or die "$0: ERROR: could not copy the bomb files from $srcdir\n";

#
# Create the ID file with the login names of the students associated 
# with this bomb
#
system("echo $studentid1 > $bombdir/ID") == 0
    or die "$0: ERROR: could not write to $bombdir/ID file\n";

if ($studentid2) {
  system("echo $studentid2 >> $bombdir/ID") == 0
    or die "$0: ERROR: could not write to $bombdir/ID file\n";
}

#
# Create the README file that identifies the bomb number and 
# the students who own the bomb.
#
system("echo \"This is bomb $bombid for lab $labid.\n\nIt is owned by the following student(s):\n$studentid1\n$studentid2\" > $bombdir/README") == 0
    or die "$0: ERROR: could not create $bombdir/README file\n";

exit;
