#!/usr/bin/perl 
#!/usr/local/bin/perl 
use Getopt::Std;

#######################################################################
# sendbomb - packages and mails an existing bomb to a user
#
# Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
#######################################################################

$| = 1; # autoflush output on every print statement

#
# usage - print help message and terminate
#
sub usage 
{
    printf STDERR "$_[0]\n";
    printf STDERR "Usage: $0 [-h] -l <labid> -i <bombid> -m <sendmail> -e <emailaddr> -u <user1> [-v <user2>]\n";
    printf STDERR "Options:\n";
    printf STDERR "  -i <bombid>    Integer bomb ID\n";
    printf STDERR "  -l <lab id>    Unique arbitrary name for this Lab\n";
    printf STDERR "  -e <emailaddr> Destination email address\n";
    printf STDERR "  -h             Print this message\n";
    printf STDERR "  -m <sendmail>  Absolute path of sendmail\n";
    printf STDERR "  -u <usr1>      Login id of student 1\n"; 
    printf STDERR "  -v <usr2>      Login id of student 2 (default: none)\n";
    die "\n" ;
}


##############
# Main routine
##############

# 
# Parse and check the command line arguments
#
getopts('hl:i:m:e:u:v:');
if ($opt_h) {
    usage();
}

$bombid = $opt_i
    or usage("Missing bomb ID argument (-i)\n");
$labid = $opt_l
    or usage("Missing lab ID argument (-l)\n");
$sendmail = $opt_m
    or usage("Missing sendmail argument (-m)\n");
$emailaddr = $opt_e
    or usage("Missing destination email adress (-e)\n");
$user1 = $opt_u
    or usage("Missing required student ID (-u)\n");
$user2 = $opt_v;

#
# Make sure the files we need are available
#
$bombdir = "./bombs";
$bombname = "bomb$bombid";
(-e $sendmail and -x $sendmail) 
    or die "$0: ERROR: $sendmail does not exist or is not executable.\n";
(-e "$bombdir/$bombname" and -d "$bombdir/$bombname")
    or die "$0: ERROR: Couldn't find directory $bombdir/$bombname\n";

# Tar up and uuencode the bomb and bomb.c files
$uufile = "/tmp/$bombname.$$";
system("cd $bombdir; tar cf - $bombname/{bomb,bomb.c} | uuencode $bombname.tar > /tmp/$bombname.$$") == 0
    or die "$0: ERROR: Couldn't tar and encode $bombname\n";

# Create the body of the email message to the student
$headerfile = "/tmp/header.$$";
open(MSG, ">$headerfile") 
    or die "$0: ERROR: Couldn't open $headerfile\n";
print MSG "Subject: Your binary bomb (#$bombid)\n\n";
print MSG "Welcome to the bomb squad for lab $labid!  Here is the bomb (bomb #$bombid)\nthat you ";
    if ($user2) {
	print MSG "($user1 and $user2)";
    }
else {
    print MSG "($user1)";
}
print MSG " are responsible for defusing.\n";
print MSG <<"EOF";

Please take a moment to review the following instructions on how to
get the most "bang" out of your bomb. Your bomb is a uuencoded tar
file that is included in the body of this email message. Depending on
your email client, there are two ways to extract your bomb:

Case 1: Most email clients will show your bomb as an attachment called
  "$bombname.tar". In this case, save the attachment (NOT THE EMAIL
  MESSAGE!) to a file called "$bombname.tar", copy the file to a Unix
  machine, and then type "tar xvf $bombname.tar". Your bomb will be in 
  the file called "./$bombname/bomb".

Case 2: If your email reader does not show the bomb as an attachment,
  save the entire email message as a text file called "foo.txt", copy
  the file to a Unix machine, and then type 
  "uudecode foo.txt; tar xvf $bombname.tar". As before, your bomb will 
  be in "./$bombname/bomb". 

Now try and guess the phrases!  I hope you guess the right ones,
because otherwise you will go... BOOM! 
EOF

close(MSG)
    or die "$0: ERROR: Couldn't close $msgfile\n";

# 
# Cat together the mail message we'll send the students
#
$mailfile = "/tmp/mail.$$";
system("cat $headerfile $uufile > $mailfile") == 0
    or die "$0: ERROR: Couldn't cat mail message.\n";

#
# Mail the message to the students
#
system("$sendmail -bm $emailaddr < $mailfile") == 0
    or die "$0: ERROR: Couldn't send $bombname to $emailaddr.\n";

# Clean up the tmp directory
system("rm -rf $uufile $mailfile $headerfile");

exit;
