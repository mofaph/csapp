#!/usr/bin/perl 
#!/usr/local/bin/perl 
use Getopt::Std;

#######################################################################
# stopbomblab - kills all running instances of requestd and reportd
#
# Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
#######################################################################

open(PS, "ps -e|")
    or die "$0: ERROR: Couldn't execute the ps command\n";	

while ($line = <PS>) {
    chomp($line);
   ($pid, $tty, $time, $cmd) = split(" ", $line);
#   print "pid=$pid tty=$tty time=$time cmd=$cmd\n";

    # Kill all bomb-requestd processes
    if ($cmd =~ /bomb-req/) {
	if (system("kill -9 $pid") != 0) {
	    warn "$0: WARNING: Couldn't kill bomb-requestd process $pid\n";
	} else {
	    print "$0: killed process $pid\n";
	}
    }

    # Kill all bomb-reportd processes
    if ($cmd =~ /bomb-rep/) {
	if (system("kill -9 $pid") != 0) {
	    warn "$0: WARNING: Couldn't kill bomb-reportd process $pid\n";
	} else {
	    print "$0: killed process $pid\n";
	}
    }

}	

exit;



