#!/usr/bin/perl 
#!/usr/local/bin/perl 
use Getopt::Std;

# parameterize the autograder
$NUMPHASES = 6;         # Number of regular phases
$MAXEXPLOSIONS = 40;    # Max number of explosions we'll count
$MAXSTRLEN = 256;       # Max legal length of a defusing string

#######################################################################
# grade-bomblab - The CS:APP Bomb Lab autograder
#
# Scans the bomb spool file once, validates and grades each bomb, and
# reports the results on a Web page.
#
# Copyright (c) 2003, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
#######################################################################

# autoflush output on every print statement
$| = 1; 

# Any files created by this script are readable only by the user
umask(0077); 

#
# usage - print help message and terminate
#
sub usage 
{
    printf STDERR "$0: ERROR: $_[0]\n";
    printf STDERR "Usage: $0 [-hqv] -l <labid> -b <bombdir> -s <spoolfile> -w <webpage> [-t <secretfile>] [-g <gradefile>] \n";
    printf STDERR "Options:\n";
    printf STDERR "  -h           Print this message\n";
    printf STDERR "  -b <bombdir> Directory where bombs are stored\n";
    printf STDERR "  -l <labid>   Unique arbitrary name for this lab\n";
    printf STDERR "  -s <file>    email spool file\n";
    printf STDERR "  -g <file>    Output grade file\n";
    printf STDERR "  -w <file>    Output Web page\n";
    printf STDERR "  -t <file>    File with names of secret solvers\n";
    printf STDERR "  -q           Run quietly\n";
    printf STDERR "  -v           Validate each solution\n";
    die "\n";
}

##############
# Main routine
##############

# 
# Parse and check the command line arguments
#
getopts('hqvs:g:l:t:w:b:');
if ($opt_h) {
    usage();
}
$spoolfile = $opt_s
    or usage("Missing spool file argument (-s)\n");
$bombsdir = $opt_b
    or usage("Missing bomb directory argument (-b)\n");
$webpage = $opt_w
    or usage("Missing output Web page argument (-w)\n");
$labid = $opt_l
    or usage("Missing lab ID argument (-l)\n");

# Set the optional args
$gradefile = $opt_g;
$secretfile = $opt_t;
$verbose = !$opt_q;
$validate = $opt_v;

# Open the input spool file
open(SPOOLFILE, $spoolfile) 
    or die "$0: ERROR: could not open $spoolfile: $!\n";

# Initialize the results hash
%RESULTS = ();

# Read spool file and gather results for each bomb in this Lab
if ($verbose) {
    print "Reading spool file.\n";
}

$linenum = 0;
while (<SPOOLFILE>) {
    $linenum++;
    $line = $_;     # lower-case the line
    chomp($line);   # remove trailing newline
    
    # Process bomb-header lines in the spool file.
    if ($line =~ /^bomb-header:/) {
	($tmp, $hdrlabid, $bombid, $user, $event, $phase) = split(":", $line);
	
	# Ignore this header if it is not from a bomb in the current lab
	if ($hdrlabid ne $labid) {
	    next;
	}

	# Ignore this header if has an invalid phase, probably
	# because a student hacked the notification message
	if ($phase > $NUMPHASES + 1) {
	    warn "$0: Bad phase in header in line $linenum ($tmp:$hdrlabid:$bombid:$user:$event:$phase). Probably hacked. Ignored.\n";
	    next;
	}

	# If this is the first activity for this bomb, create a new
	# entry in the hash
	if (!exists $RESULTS{$bombid}) {
	    $RESULTS{$bombid} = [0, 0]; # [defusions, explosions] 
	}
	
	# Retrieve the record of this bomb from the results hash
	$maxdefused = $RESULTS{$bombid}[0];
	$numexploded = $RESULTS{$bombid}[1];
	
	# If this event is an explosion, simply increment the 
	# number of explosions for this bomb
	if ($event eq "exploded") {
	    $numexploded++;
	}
	
	# If this event is a defusion, remember the largest phase 
	# defused so far and the authenticating strings.
	if (($event eq "defused") and ($phase >= $maxdefused)) {
	    $maxdefused = $phase;
	    for ($i = 0; $i < $phase; $i++) {
		$newline = <SPOOLFILE>;
		chomp($newline);
		$linenum++;
		
		# very tricky: the split must work even if the defusing
		# string ($newstring) contains a ':'
		($newtmp, $newlabid, $newbombid, 
		 $newuser, $newphase, $newstring) = 
		     split(":", $newline, 6);
		if ($newtmp ne "bomb-string") {
		    $hdrline = $linenum - $i - 1;
		    warn "$0: Line $linenum ($newline) is not a valid bomb-string line. Most likely, the student hacked the bomb-header in line $hdrline. Ignored.\n";
		    $maxdefused = 0;
		    last;
		}
		if ($newphase > $maxdefused) {
		    warn "$0: Invalid phase number in line $linenum ($newline). Probably hacked. Ignored.\n";
		    $maxdefused = 0;
		    last;
		}
		
		if (length($newstring) > $MAXSTRLEN) {
		    warn "$0: Defusing string line too long in line $linenum ($newstring). Probably hacked. Ignored.\n";
		    $maxdefused = 0;
		    last;
		}

		$RESULTS{$newbombid}[$newphase+1] = $newstring;
	    }
	}

	# Write back defusion/explosion stats to the RESULTS hash
	$RESULTS{$bombid}[0] = $maxdefused;
	$RESULTS{$bombid}[1] = $numexploded;
    }
}

close(SPOOLFILE)
    or die "$0: ERROR: could not close $spoolfile: $!\n";

# 
# At this point, we have scanned the entire spool file and now have
# a complete record for each bomb in the RESULTS hash, including the 
# maximum number of defusions [0], the total number of explosions [1], 
# and the authenticating strings for each defused phase [2..defused-1].
# 

# 
# Sanity check: if hash is empty, we probably called the autograder with the
# wrong lab ID (-l argument).
#
#%RESULTS or
#    die "$0: ERROR: Didn't find any submissions in the spool file whose Lab ID was $labid. Did you call me with the correct Lab ID (-l) argument?\n";


# 
# Optional list of (people,score) pairs
#
if ($gradefile) {
    open(GRADE, ">$gradefile") 
	or die "$0: ERROR: Couldn't open output $gradefile: $!\n";
}

# 
# Optional list of people who solved the secret phase
#
if ($secretfile) {
    open(SECRET, ">$secretfile") 
	or die "$0: ERROR: Couldn't open $secretfile: $!\n";
}

# 
# Make a new Web page in a scratch file
#
$tmpwebpage = "/tmp/webpage.$$";
open(WEB, ">$tmpwebpage") 
    or die "$0: ERROR: could not open $tmpwebpage: $!\n";

# 
# Print the standard Web page header
#
print WEB <<"EOF";
<html>
<head>
<title>Bomb Stats for '$labid'</title>
</head>
<body bgcolor=ffffff>

<h2>Bomb Stats for '$labid'</h2>

This file is updated continuously. It contains the latest information
that we have received from your bomb. Your bomb will not show up here
until you have defused or exploded a phase.  Your most recent solution
has been checked for validity. If your solution is marked <font color=ff0000><b>INVALID</b></font>, 
this means that the autograder couldn't authenticate your solution.
You won't receive any credit for an invalid solution.
EOF

print WEB "<p>Last updated: ", scalar localtime, "\n";

print WEB <<"EOF";

<p>
<table border=0 cellspacing=1 cellpadding=1 cols=5>
<tr>
<th bgcolor = #aaaaaa align=center>Bomb Name</th>
<th bgcolor = #aaaaaa align=center>Phases Defused</th>
<th bgcolor = #aaaaaa align=center>Explosions</th>
<th bgcolor = #aaaaaa align=center>Score</th>
<th bgcolor = #aaaaaa align=center>Comments</th>
</tr>
EOF

# 
# Initialize some statistics variables
#
$bombcount = 0;                       # total number of bombs
$peoplecount = 0;                     # total number of people
$defusedpeoplecount = 0;              # total number of people who defused
for ($i=0; $i <= $NUMPHASES; $i++) {  # cumulative defusion histogram
    $HIST{$i} = 0;
}

# Now grade each bomb
foreach $bombid (sort {$a <=> $b} keys %RESULTS) {
    if ($verbose) {
	print "Bomb$bombid...";
    }

    if ($bombid eq "") {
	next;
    }

    # 
    # Extract the results for this bomb from the results hash
    # and elide secret phrase from solution
    #
    $numdefused = $RESULTS{$bombid}[0];
    $numexplosions = $RESULTS{$bombid}[1];
    for ($i = 1; $i <= $numdefused; $i++) {
	$studentsol[$i-1] = $RESULTS{$bombid}[$i+1];
    }

    # Make sure all the input files we need exist and are accessible
    # Notice that we're validating with the quiet (non-notifying version) 
    # of each bomb.
    $bombdir = "$bombsdir/bomb$bombid";
    $idfile = "$bombdir/ID";
    $bombfile = "$bombdir/bomb-quiet";
    (-e $bombdir and -d $bombdir) 
	or die "$0: ERROR: Couldn't find bomb directory $bombdir\n";
    (-e $idfile)
	or die "$0: ERROR: Couldn't read ID file $idfile\n";
    (-x $bombfile)
	or die "$0: ERROR: Couldn't execute $bombfile\n";

    # 
    # Get the students assigned to this bomb
    #
    open(ID, $idfile)
	or die "$0: ERROR: Couldn't open $idfile: $!\n";
    $student1 = <ID>;
    chomp($student1);
    $student2 = <ID>;
    chomp($student2);
    close(ID);

    # 
    # Create a temporary solution file 
    #
    $tmpfile = "/tmp/solution.$$";
    open(SOLUTION, ">$tmpfile") 
	or die "$0: ERROR: Couldn't open $tmpfile\n";
    for ($i = 0; $i < $numdefused; $i++) {
	$phrase = $RESULTS{$bombid}[$i+2];
	print SOLUTION "$phrase\n";
    }
    close(SOLUTION)
	or die "$0: ERROR: Couldn't open $tmpfile\n";
    
    #
    # Now validate by running the bomb with partial solutions 
    # enabled (i.e., GRADE_BOMB environment variable set)
    #
    $valid = 1;
    if ($validate) {
	if ($verbose) {
	    print "validating...";
	}
	system("(export GRADE_BOMB='y';$bombfile $tmpfile>/dev/null 2>&1)") == 0 
	    or $valid = 0;
    }

    if (!$valid and $verbose) {
	print "Bomb$bombid solution is invalid!\n";
	for ($i = 1; $i <= $numdefused; $i++) {
	    print "    $i:$studentsol[$i-1]\n"; 
	} 
    }

    # Update some statistics
    $bombcount++;
    $numstudents_this_bomb = `cat $idfile | wc -l`;
    $HIST{$numdefused}++;
    $peoplecount += $numstudents_this_bomb;
    if ($valid and $numdefused >= $NUMPHASES) {
	$totaldefused++;
	$defusedpeoplecount += $numstudents_this_bomb;
    }

    # clean up temporary solution file
    system("rm -f $tmpfile") == 0
	or die "$0: ERROR: rm -f failed\n";

    # 
    # Compute the lab score: 
    #    +10 pts for each defused phase 1-6. No extra credit for secret phase. 
    #    -1/4 pt per explosion, up to a max of -10 pts. 
    #    Round final score up to nearest integer (first 3 explosions free!)
    #
    if ($verbose) {
	print "grading...";
    }

    $netdefused = $numdefused;
    if ($numdefused > $NUMPHASES) {
	$netdefused = $NUMPHASES;
     }    
    
    $netexplosions = $numexplosions;
    if ($numexplosions > $MAXEXPLOSIONS) { # limit the explosion penalty
	$netexplosions = $MAXEXPLOSIONS;
    }

    $defusepts = $netdefused*10;
    $explodepts_round = int $netexplosions/4; # round down to nearest int

    # Invalid solutions get zero points
    if ($valid) {
	$score = $defusepts - $explodepts_round;
    }
    else {
	$score = 0;
    }

    #
    # Output the tab-separated student/grade pairs for this bomb to 
    # the gradefile
    #
    if ($gradefile) {
	print GRADE  "$student1\t$score\n";
	if ($student2) {
	    print GRADE "$student2\t$score\n";
	}
    }

    # 
    # Send the names of those who defused the secret phase to stdout
    # WARNING: This is specific to the CMU Andrew system. If you want 
    # to use this feature you might need to modify the body of
    # the following conditional statement. Can be safely ignored
    # by omitting the -t option.
    #
    if ($secretfile and ($numdefused == 7) and $valid) {
	$login = `(finger $student1\+\@andrew | grep "login name:")`;
	$name = `(finger $student1\+\@andrew | grep -v "login name:" |grep name:)`;
	chomp($login);
	chomp($name);
	$login =~ s/^\s*login name\:\s*//;
	$name =~ s/^\s*name\:\s*//;
	print SECRET "$login ($name)\n";

	if ($student2) {
	    $login = `(finger $student2\+\@andrew | grep "login name:")`;
	    $name = `(finger $student2\+\@andrew | grep -v "login name:" |grep name:)`;
	    chomp($login);
	    chomp($name);
	    $login =~ s/^\s*login name\:\s*//;
	    $name =~ s/^\s*name\:\s*//;
	    print SECRET "$login ($name)\n";
	}
    }

    #
    # Add a table row to the Web page for this bomb
    #
    if ($valid) {
	$comment = "";
    }
    else {
	$comment = "<font color=ff0000><b>INVALID</b></font>";
    }
    print WEB "<tr>\n";
    print WEB "<td bgcolor = #eeeeee align=center>bomb$bombid</td>";
    print WEB "<td bgcolor = #eeeeee align=center>$RESULTS{$bombid}[0]</td>"; # defused
    print WEB "<td bgcolor = #eeeeee align=center>$RESULTS{$bombid}[1]</td>"; # exploded
    print WEB "<td bgcolor = #eeeeee align=center>$score</td>";               # lab score
    print WEB "<td bgcolor = #eeeeee align=center>$comment</td>\n";           # valid
    print WEB "</tr>\n";

    # Terminate the status line in verbose mode
    if ($verbose) {
	print "\n";
    }

} #end iteration over each bombid

# Print the page epilogue information
print WEB "</table>\n";
print WEB "<p>Summary [phase:cnt]  \n";
for ($i = 1; $i <= $NUMPHASES+1; $i++) {
    print WEB "[$i:$HIST{$i}]  ";
}
$totaldefused = $HIST{6}+$HIST{7};
print WEB "total defused = $totaldefused/$bombcount<br>\n";
print WEB "<p>$peoplecount people working in $bombcount teams.\n";
print WEB "$defusedpeoplecount/$peoplecount people have defused their bombs.\n";
print WEB "</body></html>\n";

# Update the current web page
close(WEB) 
    or die "$0: ERROR: could not close $webpage: $!\n";
system("mv $tmpwebpage $webpage") == 0
    or die "$0: ERROR: could not create $webpage: $!\n";

# Clean up 
if ($gradefile) {
    close(GRADE) 
	or die "$0: ERROR: Couldn't close $gradefile: $!\n";
}
if ($secretfile) {
    close(SECRET) 
	or die "$0: ERROR: Couldn't close $secretfile: $!\n";
}

exit;
